(() => {
  const $ = (sel, el = document) => el.querySelector(sel);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  let docs = [];
  let selectedId = null;

  const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  const ago = (iso) => {
    const m = Math.round((Date.now() - new Date(iso)) / 60000);
    if (m < 1) return "just now";
    if (m < 60) return `${m} min ago`;
    const h = Math.round(m / 60);
    return h < 24 ? `${h} h ago` : fmtDate(iso);
  };
  const statusClass = (s) => (s === "Processed" ? "ok" : s === "Processing" ? "warn" : "bad");

  async function api(url, opts) {
    const res = await fetch(url, opts);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Something went wrong.");
    return data;
  }

  function notify(msg, kind = "error") {
    const el = $("#notice");
    el.textContent = msg;
    el.className = "notice" + (kind === "info" ? " info" : "");
    el.hidden = false;
    clearTimeout(notify.t);
    notify.t = setTimeout(() => (el.hidden = true), 6000);
  }

  /* ---------- documents ---------- */
  function renderDocs() {
    $("#doc-count").textContent = `${docs.length} document${docs.length === 1 ? "" : "s"}`;
    $("#doc-rows").innerHTML = docs.map((d) => `
      <tr data-id="${d.id}" class="${d.id === selectedId ? "selected" : ""}" tabindex="0">
        <td class="doc-name">${esc(d.name)}</td>
        <td><span class="type-tag">${esc(d.doc_type)}</span></td>
        <td>${fmtDate(d.uploaded_at)}</td>
        <td class="num">${d.pages}</td>
        <td><span class="badge ${statusClass(d.status)}">${esc(d.status)}</span></td>
        <td class="actions"><a class="btn small" href="/files/${d.id}" target="_blank" rel="noopener">View PDF</a></td>
      </tr>`).join("") || `<tr><td colspan="6" class="empty">No documents yet. Upload a PDF to get started.</td></tr>`;
  }

  async function loadDocs() {
    docs = await api("/api/documents");
    renderDocs();
  }

  function renderExtracted(d) {
    const rows = d.fields.map((f) => `
      <div class="field">
        <dt>${esc(f.label)}</dt>
        <dd>${f.value ? esc(f.value) : '<span class="missing">Not found</span>'}</dd>
        ${f.page ? `<a class="page-ref" href="/files/${d.id}#page=${f.page}" target="_blank" rel="noopener">p. ${f.page}</a>` : "<span></span>"}
      </div>`).join("");
    const note = d.status !== "Processed"
      ? `<div class="notice">${d.status === "No text found" ? "No selectable text was found in this PDF (it may be a scan, and OCR is not included)." : "This file could not be processed."}</div>`
      : "";
    $("#extracted-body").className = "";
    $("#extracted-body").innerHTML = `
      <div class="doc-title">
        <div><strong>${esc(d.name)}</strong><span class="type-tag">${esc(d.doc_type)} · ${d.pages} pages</span></div>
        <a class="btn small" href="/files/${d.id}" target="_blank" rel="noopener">Open PDF</a>
      </div>
      ${note}
      <dl class="fields">${rows}</dl>`;
  }

  async function selectDoc(id) {
    selectedId = id;
    renderDocs();
    renderExtracted(await api(`/api/documents/${id}`));
  }

  $("#doc-rows").addEventListener("click", (e) => {
    if (e.target.closest("a")) return;
    const tr = e.target.closest("tr[data-id]");
    if (tr) selectDoc(Number(tr.dataset.id));
  });
  $("#doc-rows").addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const tr = e.target.closest("tr[data-id]");
      if (tr) selectDoc(Number(tr.dataset.id));
    }
  });

  /* ---------- upload ---------- */
  const fileInput = $("#file-input");
  $("#upload-btn").addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0];
    if (!file) return;
    const btn = $("#upload-btn");
    btn.disabled = true;
    btn.textContent = "Processing…";
    try {
      const fd = new FormData();
      fd.append("file", file);
      const doc = await api("/api/upload", { method: "POST", body: fd });
      await loadDocs();
      await selectDoc(doc.id);
      notify(doc.status === "Processed" ? `Processed “${doc.name}” — ${doc.pages} page(s) indexed.` : `“${doc.name}”: ${doc.status}.`, doc.status === "Processed" ? "info" : "error");
    } catch (err) {
      notify(err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = "Upload PDF";
      fileInput.value = "";
    }
  });

  /* ---------- ask ---------- */
  function renderAnswer(r) {
    const sources = r.sources.map((s) => `
      <div class="source"><b>Source:</b>
        <a href="/files/${s.doc_id}#page=${s.page}" target="_blank" rel="noopener">${esc(s.doc_name)} — Page ${s.page}</a>
        ${s.snippet ? `<blockquote class="snippet">${esc(s.snippet)}</blockquote>` : ""}
      </div>`).join("");
    $("#answer").innerHTML = `
      <div class="answer ${r.found ? "" : "notfound"}">
        <div class="answer-label">${r.found ? "AI answer" : "Not found"}</div>
        <div class="answer-text">${esc(r.answer)}</div>
        ${sources}
        <div class="engine-note">${r.found ? `Answered with: ${esc(r.engine)}` : "Answers only use information from the uploaded documents."}</div>
      </div>`;
  }

  async function ask(question) {
    question = question.trim();
    if (!question) return;
    const btn = $("#ask-btn");
    btn.disabled = true;
    btn.textContent = "Thinking…";
    $("#answer").innerHTML = `<div class="thinking">Searching the documents…</div>`;
    try {
      renderAnswer(await api("/api/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question }) }));
      loadRecent();
    } catch (err) {
      $("#answer").innerHTML = "";
      notify(err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = "Ask";
    }
  }

  $("#ask-form").addEventListener("submit", (e) => {
    e.preventDefault();
    ask($("#question").value);
  });
  $("#chips").addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    $("#question").value = chip.textContent;
    ask(chip.textContent);
  });

  /* ---------- recent questions ---------- */
  async function loadRecent() {
    const items = await api("/api/questions");
    $("#recent-list").innerHTML = items.map((q) => {
      const src = q.sources.length ? `Source: ${q.sources.map((s) => `${esc(s.doc_name)} — Page ${s.page}`).join("; ")}` : "No source found";
      return `<li>
        <span class="q">${esc(q.question)}</span>
        <span class="a">${esc(q.answer)}</span>
        <span class="meta">${src} · ${ago(q.asked_at)}</span>
      </li>`;
    }).join("") || `<li class="muted">No questions yet.</li>`;
  }

  /* ---------- nav highlight & engine ---------- */
  document.querySelectorAll(".nav a").forEach((a) =>
    a.addEventListener("click", () => {
      document.querySelectorAll(".nav a").forEach((x) => x.classList.remove("active"));
      a.classList.add("active");
    }));

  api("/api/status").then((s) => ($("#engine").textContent = `Engine: ${s.engine}`)).catch(() => {});
  loadDocs().catch((e) => notify(e.message));
  loadRecent().catch(() => {});
})();
